package pl.cp4.CreaditCard;

public class CantReassignLimitTwice extends IllegalStateException{
}
