package pl.cp4;

public class Greeter {
    public void greet(String name){

        System.out.println(String.format("Hello %s", name));
    }

}
