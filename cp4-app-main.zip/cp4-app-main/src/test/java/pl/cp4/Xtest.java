package pl.cp4;

import org.junit.jupiter.api.Test;

public class Xtest {
    @Test
    void testIt(){
        String x = "Hello";
    }
}
